// Crypto Algotrading Portfolio Dashboard JavaScript

// Sample data based on the provided JSON
const portfolioData = {
  portfolioSummary: {
    totalValue: 452000,
    todaysPnl: 1134,
    mtdPnl: 17400,
    avgSharpe: 1.89
  },
  dailyPnl: [
    {"date": "Aug 1", "realized": 1556, "unrealized": 180},
    {"date": "Aug 2", "realized": 2348, "unrealized": 3},
    {"date": "Aug 3", "realized": 2694, "unrealized": -44},
    {"date": "Aug 4", "realized": 1495, "unrealized": -43},
    {"date": "Aug 5", "realized": 820, "unrealized": -295},
    {"date": "Aug 6", "realized": 1127, "unrealized": 112},
    {"date": "Aug 7", "realized": 2846, "unrealized": -67},
    {"date": "Aug 8", "realized": 987, "unrealized": 246},
    {"date": "Aug 9", "realized": 1654, "unrealized": -89},
    {"date": "Aug 10", "realized": 766, "unrealized": 157},
    {"date": "Aug 11", "realized": 1124, "unrealized": -23},
    {"date": "Aug 12", "realized": 2235, "unrealized": 68},
    {"date": "Aug 13", "realized": 3089, "unrealized": 112}
  ],
  subaccounts: [
    {"id": 1, "name": "MainDayUSDT", "type": "Day Trading", "size": 75600, "leverage": "20x", "exchange": "Bitget", "pnl": 166, "winRate": 64.4, "drawdown": 16.6, "sharpe": 2.52},
    {"id": 2, "name": "HFTRisk", "type": "High-Frequency", "size": 63400, "leverage": "80x", "exchange": "Bitget", "pnl": 174, "winRate": 62.9, "drawdown": 6.3, "sharpe": 1.47},
    {"id": 3, "name": "BTCPerpSwing", "type": "Swing Trading", "size": 51200, "leverage": "5x", "exchange": "Phemex", "pnl": 111, "winRate": 45.9, "drawdown": 9.9, "sharpe": 1.74},
    {"id": 4, "name": "DeFiYield", "type": "Day Trading", "size": 31000, "leverage": "12x", "exchange": "Bitget", "pnl": 48, "winRate": 50.4, "drawdown": 9.2, "sharpe": 1.96},
    {"id": 5, "name": "ETHQuant", "type": "Day Trading", "size": 29400, "leverage": "15x", "exchange": "Phemex", "pnl": 90, "winRate": 47.8, "drawdown": 17.0, "sharpe": 1.30},
    {"id": 6, "name": "KrakenSwing", "type": "Swing Trading", "size": 64300, "leverage": "3x", "exchange": "Kraken", "pnl": -12, "winRate": 41.2, "drawdown": 18.6, "sharpe": 1.20},
    {"id": 7, "name": "SpotMain", "type": "Spot", "size": 3900, "leverage": "N/A", "exchange": "Bitget", "pnl": 6, "winRate": 0, "drawdown": 0, "sharpe": 0},
    {"id": 8, "name": "SpotMinor", "type": "Spot", "size": 1600, "leverage": "N/A", "exchange": "Kraken", "pnl": 1, "winRate": 0, "drawdown": 0, "sharpe": 0},
    {"id": 9, "name": "PhemexHedge", "type": "Futures", "size": 55100, "leverage": "50x", "exchange": "Phemex", "pnl": 235, "winRate": 51.0, "drawdown": 11.3, "sharpe": 1.90},
    {"id": 10, "name": "ArbitrageX", "type": "High-Frequency", "size": 27500, "leverage": "100x", "exchange": "Bitget", "pnl": 109, "winRate": 63.0, "drawdown": 16.8, "sharpe": 2.50},
    {"id": 11, "name": "KrakenFutAlt", "type": "Futures", "size": 21500, "leverage": "10x", "exchange": "Kraken", "pnl": 54, "winRate": 45.0, "drawdown": 15.5, "sharpe": 1.50},
    {"id": 12, "name": "LTCQuant", "type": "Day Trading", "size": 27500, "leverage": "25x", "exchange": "Phemex", "pnl": 1, "winRate": 49.0, "drawdown": 13.9, "sharpe": 2.00}
  ],
  transactions: [
    {"id": 1, "time": "Aug 9 18:41", "account": "ETHQuant", "exchange": "Phemex", "asset": "ETHUSDT", "side": "Long", "qty": 3.88, "price": 2600.35, "fee": 5.04, "pnl": 337.23},
    {"id": 2, "time": "Aug 9 15:44", "account": "BTCPerpSwing", "exchange": "Phemex", "asset": "BTCUSDT", "side": "Short", "qty": 0.286, "price": 43079.61, "fee": 6.16, "pnl": -78.20},
    {"id": 3, "time": "Aug 9 20:01", "account": "DeFiYield", "exchange": "Bitget", "asset": "AVAXUSDT", "side": "Short", "qty": 602.9, "price": 2.18, "fee": 0.66, "pnl": 42.39},
    {"id": 4, "time": "Aug 10 18:54", "account": "KrakenFutAlt", "exchange": "Kraken", "asset": "XRPUSDT", "side": "Long", "qty": 462.0, "price": 0.89, "fee": 0.21, "pnl": 96.26},
    {"id": 5, "time": "Aug 10 17:51", "account": "ArbitrageX", "exchange": "Bitget", "asset": "SOLUSDT", "side": "Short", "qty": 45.2, "price": 142.15, "fee": 3.21, "pnl": -156.88}
  ]
};

// Global variables
let dailyPnlChart = null;
let allocationChart = null;
let currentFilters = {
  exchange: '',
  accountType: '',
  dateRange: 'aug1-13'
};
let sortConfig = {
  key: null,
  direction: 'asc'
};

// Utility functions
function formatCurrency(amount, showSign = false) {
  const formatted = new Intl.NumberFormat('en-CA', {
    style: 'currency',
    currency: 'CAD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(Math.abs(amount));
  
  if (showSign && amount !== 0) {
    return amount > 0 ? `+${formatted}` : `-${formatted}`;
  }
  return formatted;
}

function formatNumber(num, decimals = 2) {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  }).format(num);
}

function formatPercentage(num, decimals = 1) {
  return `${formatNumber(num, decimals)}%`;
}

function getPnlClass(value) {
  if (value > 0) return 'positive';
  if (value < 0) return 'negative';
  return 'neutral';
}

function getExchangeBadgeClass(exchange) {
  return `exchange-badge exchange-${exchange.toLowerCase()}`;
}

function getSideBadgeClass(side) {
  return `side-badge side-${side.toLowerCase()}`;
}

// Chart creation functions
function createDailyPnlChart() {
  const ctx = document.getElementById('dailyPnlChart').getContext('2d');
  
  const chartColors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B'];
  
  dailyPnlChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: portfolioData.dailyPnl.map(d => d.date),
      datasets: [
        {
          label: 'Realized P&L',
          data: portfolioData.dailyPnl.map(d => d.realized),
          backgroundColor: chartColors[0],
          borderColor: chartColors[0],
          borderWidth: 1
        },
        {
          label: 'Unrealized P&L',
          data: portfolioData.dailyPnl.map(d => d.unrealized),
          backgroundColor: chartColors[1],
          borderColor: chartColors[1],
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          stacked: false,
          grid: {
            display: false
          }
        },
        y: {
          stacked: false,
          beginAtZero: false,
          ticks: {
            callback: function(value) {
              return formatCurrency(value);
            }
          }
        }
      },
      plugins: {
        legend: {
          position: 'top',
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return `${context.dataset.label}: ${formatCurrency(context.raw, true)}`;
            }
          }
        }
      }
    }
  });
}

function createAllocationChart() {
  const ctx = document.getElementById('allocationChart').getContext('2d');
  
  // Group accounts by exchange for allocation
  const exchangeAllocations = {};
  portfolioData.subaccounts.forEach(account => {
    if (!exchangeAllocations[account.exchange]) {
      exchangeAllocations[account.exchange] = 0;
    }
    exchangeAllocations[account.exchange] += account.size;
  });
  
  const chartColors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F'];
  const labels = Object.keys(exchangeAllocations);
  const data = Object.values(exchangeAllocations);
  
  allocationChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: chartColors.slice(0, labels.length),
        borderWidth: 2,
        borderColor: '#ffffff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const total = context.dataset.data.reduce((a, b) => a + b, 0);
              const percentage = ((context.raw / total) * 100).toFixed(1);
              return `${context.label}: ${formatCurrency(context.raw)} (${percentage}%)`;
            }
          }
        }
      }
    }
  });
}

// Table rendering functions
function renderSubAccountsTable(accounts = portfolioData.subaccounts) {
  const tbody = document.getElementById('subAccountsBody');
  
  tbody.innerHTML = accounts.map(account => `
    <tr>
      <td><strong>${account.name}</strong></td>
      <td>${account.type}</td>
      <td class="currency">${formatCurrency(account.size)}</td>
      <td>${account.leverage}</td>
      <td><span class="${getExchangeBadgeClass(account.exchange)}">${account.exchange}</span></td>
      <td class="currency ${getPnlClass(account.pnl)}">${formatCurrency(account.pnl, true)}</td>
      <td class="percentage">${formatPercentage(account.winRate)}</td>
      <td class="percentage">${formatPercentage(account.drawdown)}</td>
      <td>${formatNumber(account.sharpe)}</td>
    </tr>
  `).join('');
}

function renderTransactionsTable(transactions = portfolioData.transactions) {
  const tbody = document.getElementById('transactionsBody');
  
  tbody.innerHTML = transactions.map(tx => `
    <tr>
      <td class="mono">${tx.time}</td>
      <td>${tx.account}</td>
      <td><span class="${getExchangeBadgeClass(tx.exchange)}">${tx.exchange}</span></td>
      <td class="mono">${tx.asset}</td>
      <td><span class="${getSideBadgeClass(tx.side)}">${tx.side}</span></td>
      <td class="mono">${formatNumber(tx.qty, 3)}</td>
      <td class="currency mono">${formatCurrency(tx.price)}</td>
      <td class="currency">${formatCurrency(tx.fee)}</td>
      <td class="currency ${getPnlClass(tx.pnl)}">${formatCurrency(tx.pnl, true)}</td>
    </tr>
  `).join('');
}

// Filtering functions
function applyFilters() {
  let filteredAccounts = [...portfolioData.subaccounts];
  
  if (currentFilters.exchange) {
    filteredAccounts = filteredAccounts.filter(account => 
      account.exchange === currentFilters.exchange
    );
  }
  
  if (currentFilters.accountType) {
    filteredAccounts = filteredAccounts.filter(account => 
      account.type === currentFilters.accountType
    );
  }
  
  // Apply current sort if exists
  if (sortConfig.key) {
    filteredAccounts = sortAccounts(filteredAccounts, sortConfig.key, sortConfig.direction);
  }
  
  renderSubAccountsTable(filteredAccounts);
  updateKPIsBasedOnFilter(filteredAccounts);
}

function updateKPIsBasedOnFilter(accounts) {
  // Calculate filtered KPIs
  const totalFiltered = accounts.reduce((sum, acc) => sum + acc.size, 0);
  const totalPnl = accounts.reduce((sum, acc) => sum + acc.pnl, 0);
  const avgSharpe = accounts.reduce((sum, acc) => sum + acc.sharpe, 0) / accounts.length || 0;
  
  // Update display (only if filtering is active)
  if (currentFilters.exchange || currentFilters.accountType) {
    document.getElementById('totalValue').textContent = formatCurrency(totalFiltered);
    document.getElementById('todayPnl').textContent = formatCurrency(totalPnl, true);
    document.getElementById('avgSharpe').textContent = formatNumber(avgSharpe);
  } else {
    // Reset to original values
    document.getElementById('totalValue').textContent = formatCurrency(portfolioData.portfolioSummary.totalValue);
    document.getElementById('todayPnl').textContent = formatCurrency(portfolioData.portfolioSummary.todaysPnl, true);
    document.getElementById('avgSharpe').textContent = formatNumber(portfolioData.portfolioSummary.avgSharpe);
  }
}

// Sorting functions
function sortAccounts(accounts, key, direction) {
  return accounts.sort((a, b) => {
    let aVal = a[key];
    let bVal = b[key];
    
    // Handle numeric values
    if (key === 'size' || key === 'pnl' || key === 'winRate' || key === 'drawdown' || key === 'sharpe') {
      aVal = parseFloat(aVal);
      bVal = parseFloat(bVal);
    }
    
    // Handle leverage (convert to numeric, handle "N/A")
    if (key === 'leverage') {
      aVal = a[key] === 'N/A' ? 0 : parseFloat(a[key]);
      bVal = b[key] === 'N/A' ? 0 : parseFloat(b[key]);
    }
    
    if (aVal < bVal) return direction === 'asc' ? -1 : 1;
    if (aVal > bVal) return direction === 'asc' ? 1 : -1;
    return 0;
  });
}

function handleSort(column) {
  // Toggle direction if same column, otherwise reset to asc
  if (sortConfig.key === column) {
    sortConfig.direction = sortConfig.direction === 'asc' ? 'desc' : 'asc';
  } else {
    sortConfig.key = column;
    sortConfig.direction = 'asc';
  }
  
  // Update visual indicators
  document.querySelectorAll('.sortable').forEach(th => {
    th.classList.remove('sort-asc', 'sort-desc');
  });
  
  const currentTh = document.querySelector(`[data-column="${column}"]`);
  currentTh.classList.add(sortConfig.direction === 'asc' ? 'sort-asc' : 'sort-desc');
  
  // Apply filters (which will also apply sorting)
  applyFilters();
}

// Event listeners
function setupEventListeners() {
  // Filter change handlers
  document.getElementById('exchangeFilter').addEventListener('change', (e) => {
    currentFilters.exchange = e.target.value;
    applyFilters();
  });
  
  document.getElementById('accountTypeFilter').addEventListener('change', (e) => {
    currentFilters.accountType = e.target.value;
    applyFilters();
  });
  
  document.getElementById('dateRange').addEventListener('change', (e) => {
    currentFilters.dateRange = e.target.value;
    // Note: In a real app, this would filter the daily P&L chart data
  });
  
  // Reset filters
  document.getElementById('resetFilters').addEventListener('click', () => {
    currentFilters = {
      exchange: '',
      accountType: '',
      dateRange: 'aug1-13'
    };
    
    // Reset form values
    document.getElementById('exchangeFilter').value = '';
    document.getElementById('accountTypeFilter').value = '';
    document.getElementById('dateRange').value = 'aug1-13';
    
    // Reset sort
    sortConfig = { key: null, direction: 'asc' };
    document.querySelectorAll('.sortable').forEach(th => {
      th.classList.remove('sort-asc', 'sort-desc');
    });
    
    // Re-render with original data
    renderSubAccountsTable();
    updateKPIsBasedOnFilter(portfolioData.subaccounts);
  });
  
  // Sortable column headers
  document.querySelectorAll('.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const column = th.dataset.column;
      handleSort(column);
    });
  });
}

// Initialization
function init() {
  // Render initial tables
  renderSubAccountsTable();
  renderTransactionsTable();
  
  // Create charts
  createDailyPnlChart();
  createAllocationChart();
  
  // Setup event listeners
  setupEventListeners();
  
  console.log('Crypto Algotrading Dashboard initialized successfully!');
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);