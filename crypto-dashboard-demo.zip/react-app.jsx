import React, { useState, useMemo } from 'react';
import {
  ThemeProvider,
  createTheme,
  CssBaseline,
  Container,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import AssessmentIcon from '@mui/icons-material/Assessment';

import { dailyPnlData, subaccountsData, transactionsData, portfolioSummary } from './data/sampleData';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    success: {
      main: '#2e7d32',
    },
    error: {
      main: '#d32f2f',
    },
  },
});

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

function App() {
  const [exchangeFilter, setExchangeFilter] = useState('all');
  const [accountTypeFilter, setAccountTypeFilter] = useState('all');

  // Filtered subaccounts data
  const filteredSubaccounts = useMemo(() => {
    return subaccountsData.filter(account => {
      const matchesExchange = exchangeFilter === 'all' || account.exchange === exchangeFilter;
      const matchesType = accountTypeFilter === 'all' || account.accountType === accountTypeFilter;
      return matchesExchange && matchesType;
    });
  }, [exchangeFilter, accountTypeFilter]);

  // KPI Card component
  const KPICard = ({ title, value, icon, color = 'primary', format = 'currency' }) => (
    <Card elevation={3}>
      <CardContent>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box>
            <Typography variant="subtitle2" color="textSecondary" gutterBottom>
              {title}
            </Typography>
            <Typography variant="h4" color={color}>
              {format === 'currency' ? `$${value.toLocaleString()}` : 
               format === 'percentage' ? `${(value * 100).toFixed(1)}%` : 
               format === 'ratio' ? value.toFixed(2) : value}
            </Typography>
          </Box>
          <Box color={`${color}.main`}>
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );

  // Subaccounts table columns
  const subaccountColumns = [
    { field: 'accountName', headerName: 'Account', width: 150 },
    { field: 'accountType', headerName: 'Type', width: 130 },
    {
      field: 'sizeCad',
      headerName: 'Size (CAD)',
      width: 120,
      type: 'number',
      valueFormatter: (params) => `$${params.value.toLocaleString()}`,
    },
    { field: 'leverage', headerName: 'Leverage', width: 100 },
    { field: 'exchange', headerName: 'Exchange', width: 100 },
    {
      field: 'dailyPnl',
      headerName: 'Daily P&L',
      width: 120,
      type: 'number',
      valueFormatter: (params) => `$${params.value.toFixed(2)}`,
      cellClassName: (params) => params.value >= 0 ? 'positive-pnl' : 'negative-pnl',
    },
    {
      field: 'winRate',
      headerName: 'Win Rate',
      width: 100,
      type: 'number',
      valueFormatter: (params) => `${(params.value * 100).toFixed(1)}%`,
    },
    {
      field: 'maxDrawdown',
      headerName: 'Max DD',
      width: 100,
      type: 'number',
      valueFormatter: (params) => `${(params.value * 100).toFixed(1)}%`,
    },
    {
      field: 'sharpeRatio',
      headerName: 'Sharpe',
      width: 90,
      type: 'number',
      valueFormatter: (params) => params.value.toFixed(2),
    },
  ];

  // Transactions table columns
  const transactionColumns = [
    { field: 'timestamp', headerName: 'Time', width: 150 },
    { field: 'account', headerName: 'Account', width: 130 },
    { field: 'exchange', headerName: 'Exchange', width: 100 },
    { field: 'asset', headerName: 'Asset', width: 100 },
    {
      field: 'side',
      headerName: 'Side',
      width: 80,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === 'Long' ? 'success' : 'error'}
          size="small"
        />
      ),
    },
    {
      field: 'quantity',
      headerName: 'Quantity',
      width: 100,
      type: 'number',
      valueFormatter: (params) => params.value.toFixed(3),
    },
    {
      field: 'price',
      headerName: 'Price',
      width: 100,
      type: 'number',
      valueFormatter: (params) => `$${params.value.toLocaleString()}`,
    },
    {
      field: 'feeCad',
      headerName: 'Fee (CAD)',
      width: 100,
      type: 'number',
      valueFormatter: (params) => `$${params.value.toFixed(2)}`,
    },
    {
      field: 'realizedPnlCad',
      headerName: 'P&L (CAD)',
      width: 120,
      type: 'number',
      valueFormatter: (params) => `$${params.value.toFixed(2)}`,
      cellClassName: (params) => params.value >= 0 ? 'positive-pnl' : 'negative-pnl',
    },
  ];

  // Prepare pie chart data
  const pieData = filteredSubaccounts.map((account, index) => ({
    name: account.accountName,
    value: account.sizeCad,
    fill: COLORS[index % COLORS.length],
  }));

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container maxWidth="xl" sx={{ py: 3 }}>
        {/* Header */}
        <Box mb={4}>
          <Typography variant="h3" component="h1" gutterBottom align="center">
            🚀 Crypto Algotrading Dashboard
          </Typography>
          <Typography variant="subtitle1" align="center" color="textSecondary">
            Multi-exchange algorithmic trading portfolio with real-time P&L tracking
          </Typography>
        </Box>

        {/* KPI Cards */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <KPICard
              title="Total Portfolio Value (CAD)"
              value={portfolioSummary.totalValue}
              icon={<AccountBalanceIcon sx={{ fontSize: 40 }} />}
              color="success"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <KPICard
              title="Today's P&L"
              value={portfolioSummary.todaysPnl}
              icon={<TrendingUpIcon sx={{ fontSize: 40 }} />}
              color="info"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <KPICard
              title="Month-to-Date P&L"
              value={portfolioSummary.mtdRealizedPnl}
              icon={<ShowChartIcon sx={{ fontSize: 40 }} />}
              color="primary"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <KPICard
              title="Avg Sharpe Ratio"
              value={portfolioSummary.avgSharpe}
              icon={<AssessmentIcon sx={{ fontSize: 40 }} />}
              color="warning"
              format="ratio"
            />
          </Grid>
        </Grid>

        {/* Filters */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel>Exchange Filter</InputLabel>
              <Select
                value={exchangeFilter}
                label="Exchange Filter"
                onChange={(e) => setExchangeFilter(e.target.value)}
              >
                <MenuItem value="all">All Exchanges</MenuItem>
                <MenuItem value="Bitget">Bitget</MenuItem>
                <MenuItem value="Phemex">Phemex</MenuItem>
                <MenuItem value="Kraken">Kraken</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel>Account Type Filter</InputLabel>
              <Select
                value={accountTypeFilter}
                label="Account Type Filter"
                onChange={(e) => setAccountTypeFilter(e.target.value)}
              >
                <MenuItem value="all">All Types</MenuItem>
                <MenuItem value="Day Trading">Day Trading</MenuItem>
                <MenuItem value="High-Frequency">High-Frequency</MenuItem>
                <MenuItem value="Swing Trading">Swing Trading</MenuItem>
                <MenuItem value="Futures">Futures</MenuItem>
                <MenuItem value="Spot">Spot</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {/* Charts */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} md={8}>
            <Paper elevation={3} sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>
                Daily P&L Performance
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dailyPnlData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, '']} />
                  <Legend />
                  <Bar dataKey="realizedPnl" fill="#2e7d32" name="Realized P&L" />
                  <Bar dataKey="unrealizedPnl" fill="#ff9800" name="Unrealized P&L" />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>
                Portfolio Allocation
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Value']} />
                </PieChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>
        </Grid>

        {/* Sub-Accounts Table */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12}>
            <Paper elevation={3} sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>
                Sub-Accounts Performance
              </Typography>
              <Box sx={{ height: 400, width: '100%' }}>
                <DataGrid
                  rows={filteredSubaccounts}
                  columns={subaccountColumns}
                  pageSize={12}
                  rowsPerPageOptions={[12]}
                  disableSelectionOnClick
                  sx={{
                    '& .positive-pnl': {
                      backgroundColor: '#e8f5e8',
                      color: '#2e7d32',
                    },
                    '& .negative-pnl': {
                      backgroundColor: '#ffebee',
                      color: '#d32f2f',
                    },
                  }}
                />
              </Box>
            </Paper>
          </Grid>
        </Grid>

        {/* Recent Transactions */}
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Paper elevation={3} sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>
                Recent Transactions
              </Typography>
              <Box sx={{ height: 400, width: '100%' }}>
                <DataGrid
                  rows={transactionsData}
                  columns={transactionColumns}
                  pageSize={10}
                  rowsPerPageOptions={[10]}
                  disableSelectionOnClick
                  sx={{
                    '& .positive-pnl': {
                      backgroundColor: '#e8f5e8',
                      color: '#2e7d32',
                    },
                    '& .negative-pnl': {
                      backgroundColor: '#ffebee',
                      color: '#d32f2f',
                    },
                  }}
                />
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </ThemeProvider>
  );
}

export default App;