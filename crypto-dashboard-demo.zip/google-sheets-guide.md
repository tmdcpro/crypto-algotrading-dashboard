# Google Sheets Template Setup Guide

This guide will help you recreate the interactive crypto algotrading dashboard in Google Sheets.

## Step 1: Create New Google Sheet

1. Go to [sheets.google.com](https://sheets.google.com)
2. Create a new blank spreadsheet
3. Name it "Crypto Algotrading Dashboard"

## Step 2: Create Sheet Structure

Create the following sheets (tabs at the bottom):
- **Dashboard** (main overview)
- **Daily_PNL** (daily profit/loss data)
- **Subaccounts** (subaccount configuration)
- **Transactions** (transaction history)
- **Settings** (configuration and lookups)

## Step 3: Import Data

### Daily_PNL Sheet
Copy the data from `daily_pnl.csv` into this sheet starting at cell A1:
- Column A: date
- Column B: realized_pnl
- Column C: unrealized_pnl
- Column D: deposits
- Column E: withdrawals
- Column F: transfers
- Column G: fees

### Subaccounts Sheet
Copy the data from `subaccounts.csv` starting at cell A1:
- Column A: account_name
- Column B: account_type
- Column C: size_cad
- Column D: leverage
- Column E: exchange
- Column F: daily_pnl
- Column G: win_rate
- Column H: max_drawdown
- Column I: sharpe_ratio

### Transactions Sheet
Copy the data from `transactions.csv` starting at cell A1:
- Column A: id
- Column B: timestamp
- Column C: account
- Column D: exchange
- Column E: type
- Column F: asset
- Column G: side
- Column H: quantity
- Column I: price
- Column J: leverage
- Column K: fee_cad
- Column L: realized_pnl_cad
- Column M: notes

## Step 4: Dashboard Sheet Setup

### KPI Section (A1:D8)

**A1:** `Total Portfolio Value (CAD)`
**B1:** `=SUM(Subaccounts!C:C)`

**A2:** `Today's P&L`  
**B2:** `=SUM(Subaccounts!F:F)`

**A3:** `Month-to-Date P&L`  
**B3:** `=SUM(Daily_PNL!B:B)`

**A4:** `Max Drawdown %`  
**B4:** `=MAX(Subaccounts!H:H)`

**A5:** `Avg Sharpe Ratio`  
**B5:** `=AVERAGE(FILTER(Subaccounts!I:I, Subaccounts!I:I>0))`

### Filters Section (A10:D12)

**A10:** `Exchange Filter:`  
**B10:** `All` (dropdown: All, Bitget, Phemex, Kraken)

**A11:** `Account Type Filter:`  
**B11:** `All` (dropdown: All, Day Trading, High-Frequency, Swing Trading, Futures, Spot)

**A12:** `Date Range From:`  
**B12:** `2025-08-01` (date picker)  
**C12:** `To:`  
**D12:** `2025-08-13` (date picker)

## Step 5: Charts

### Daily PNL Chart
1. Select Daily_PNL data (A:G)
2. Insert → Chart
3. Chart type: Column chart
4. X-axis: date
5. Series: realized_pnl, unrealized_pnl
6. Title: "Daily P&L Performance"

### Portfolio Allocation Chart
1. Select Subaccounts columns A and C (account_name, size_cad)
2. Insert → Chart
3. Chart type: Pie chart
4. Title: "Portfolio Allocation by Sub-Account"

### Performance by Exchange Chart
1. Create helper data with SUMIF formulas:
   - `=SUMIF(Subaccounts!E:E,"Bitget",Subaccounts!F:F)`
   - `=SUMIF(Subaccounts!E:E,"Phemex",Subaccounts!F:F)`
   - `=SUMIF(Subaccounts!E:E,"Kraken",Subaccounts!F:F)`
2. Create bar chart

## Step 6: Add Interactivity

### Data Validation for Filters
1. Select filter cells (B10, B11)
2. Data → Data validation
3. Create dropdown lists with appropriate options

### Conditional Formatting
1. Select P&L columns
2. Format → Conditional formatting
3. Add rules:
   - If value > 0: Green background
   - If value < 0: Red background

### Dynamic Filtering (Advanced)
Use FILTER function to show filtered subaccounts:
```
=FILTER(Subaccounts!A:I,
  IF(B10="All",TRUE,Subaccounts!E:E=B10) *
  IF(B11="All",TRUE,Subaccounts!B:B=B11)
)
```

## Step 7: Formatting

### Number Formats
- Currency values: Format → Number → Currency (CAD)
- Percentages: Format → Number → Percent
- Dates: Format → Number → Date

### Cell Styling
- Header rows: Bold, colored background
- KPI values: Large font, bold
- Tables: Alternating row colors

## Step 8: Protection and Sharing

### Protect Formulas
1. Select formula cells
2. Data → Protect sheets and ranges
3. Set permissions to prevent accidental editing

### Share Settings
1. Click "Share" button
2. Add collaborators
3. Set appropriate permission levels

## Advanced Features

### Pivot Tables
Create pivot tables for:
- P&L by exchange
- Performance by account type
- Trading volume by asset

### Apps Script (Optional)
Add custom functions for:
- Automatic data refresh
- Email alerts for losses > threshold
- Export to PDF

### Data Connections
- Connect to Google Finance for crypto prices
- Link to exchange APIs for real-time data

## Maintenance

### Regular Updates
- Add new transactions daily
- Update daily P&L figures
- Recalculate performance metrics
- Backup data monthly

### Data Validation Rules
- Ensure consistent date formats
- Validate exchange names
- Check P&L calculations

This template provides a fully functional, interactive dashboard that matches the functionality of the Python and React versions while leveraging Google Sheets' collaborative features.