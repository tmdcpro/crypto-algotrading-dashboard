# Crypto Algotrading Dashboard - Complete Repository

This repository contains three different implementations of a comprehensive crypto algorithmic trading portfolio dashboard:

1. **Python Dash App** - Single-page interactive dashboard
2. **React/JavaScript App** - Modern web dashboard with Material-UI
3. **Excel/Google Sheets Template** - Fully interactive spreadsheet

## Repository Structure

```
crypto-algotrading-dashboard/
│
├── README.md                           # This file
├── .gitignore                          # Git ignore file
│
├── data/                               # Shared data files
│   ├── daily_pnl.csv                  # Daily PNL data
│   ├── subaccounts.csv                 # Subaccount configurations
│   └── transactions.csv                # Transaction history
│
├── python_dash_version/
│   ├── requirements.txt                # Python dependencies
│   ├── app.py                          # Main Dash application
│   ├── components/                     # Dash components
│   │   ├── __init__.py
│   │   ├── kpi_cards.py
│   │   ├── subaccount_table.py
│   │   └── charts.py
│   └── assets/                         # CSS styling
│       └── style.css
│
├── react_dashboard_version/
│   ├── package.json                    # Node.js dependencies
│   ├── vite.config.js                  # Vite configuration
│   ├── index.html                      # HTML entry point
│   ├── src/
│   │   ├── App.jsx                     # Main React component
│   │   ├── main.jsx                    # React entry point
│   │   ├── components/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── KPICards.jsx
│   │   │   ├── SubaccountTable.jsx
│   │   │   ├── PNLChart.jsx
│   │   │   ├── AllocationChart.jsx
│   │   │   └── FiltersPanel.jsx
│   │   ├── data/
│   │   │   └── sampleData.js
│   │   └── styles/
│   │       └── App.css
│   └── public/
│
└── spreadsheet_template/
    ├── excel_template.xlsx             # Ready-to-use Excel file
    ├── google_sheets_guide.md          # Instructions for Google Sheets
    ├── formulas_reference.txt          # Key formulas documentation
    └── data_import_instructions.md     # How to import the CSV data
```

## Quick Start

### Python Dash Version
```bash
cd python_dash_version
pip install -r requirements.txt
python app.py
# Open http://localhost:8050
```

### React Dashboard Version  
```bash
cd react_dashboard_version
npm install
npm run dev
# Open http://localhost:5173
```

### Spreadsheet Template
1. Open `spreadsheet_template/excel_template.xlsx` in Excel or LibreOffice
2. Or follow `google_sheets_guide.md` to create in Google Sheets
3. Import data from the CSV files in `/data/` folder

## Features (All Versions)

- **Portfolio Overview**: Total value, MTD PNL, key metrics
- **12 Sub-accounts**: Mix of day trading, HFT, swing trading, spot accounts
- **Multi-Exchange Support**: Bitget, Phemex, Kraken
- **Interactive Charts**: Daily PNL, allocation, drawdown curves
- **Transaction History**: All trades, deposits, withdrawals, transfers
- **Risk Metrics**: Sharpe ratio, max drawdown, win rates
- **Customizable Views**: Filters, date ranges, show/hide options
- **Editable Values**: Change PNL and related metrics auto-update

## Data Consistency

All three versions use the same underlying dataset:
- **Date Range**: August 1-13, 2025
- **Base Currency**: CAD  
- **Portfolio Value**: ~$452,000 CAD
- **12 Sub-accounts** with realistic leverage (2x-125x)
- **Sample Transactions**: 23+ realistic crypto futures trades
- **Daily PNL History**: 13 days of profit/loss data

## Development Notes

- Python version uses Plotly Dash for interactivity
- React version uses Material-UI + Recharts 
- Spreadsheet uses advanced Excel/Sheets formulas
- All versions support live editing and recalculation
- Data is completely simulated but realistic

## Contributing

This is a template/example project. Feel free to:
- Modify the data structure
- Add new sub-accounts or exchanges  
- Enhance the UI/UX
- Add new charts or metrics
- Integrate with real exchange APIs

## License

MIT License - Use freely for your own projects