// Sample data for the crypto algotrading dashboard
// This data matches the Python and spreadsheet versions

export const dailyPnlData = [
  { date: '2025-08-01', realizedPnl: 1555.89, unrealizedPnl: 179.54, deposits: 2000, withdrawals: 0, fees: 15.78 },
  { date: '2025-08-02', realizedPnl: 2348.18, unrealizedPnl: 3.17, deposits: 0, withdrawals: 0, fees: 16.17 },
  { date: '2025-08-03', realizedPnl: 2693.60, unrealizedPnl: -43.89, deposits: 0, withdrawals: 0, fees: 16.35 },
  { date: '2025-08-04', realizedPnl: 1495.02, unrealizedPnl: -43.15, deposits: 0, withdrawals: 0, fees: 15.75 },
  { date: '2025-08-05', realizedPnl: 819.59, unrealizedPnl: -294.98, deposits: 0, withdrawals: 0, fees: 15.41 },
  { date: '2025-08-06', realizedPnl: 1127.24, unrealizedPnl: 112.45, deposits: 0, withdrawals: 0, fees: 15.56 },
  { date: '2025-08-07', realizedPnl: 2845.93, unrealizedPnl: -67.23, deposits: 1000, withdrawals: 0, fees: 16.42 },
  { date: '2025-08-08', realizedPnl: 987.31, unrealizedPnl: 245.67, deposits: 0, withdrawals: 0, fees: 15.49 },
  { date: '2025-08-09', realizedPnl: 1654.44, unrealizedPnl: -89.12, deposits: 0, withdrawals: 0, fees: 15.83 },
  { date: '2025-08-10', realizedPnl: 765.89, unrealizedPnl: 156.78, deposits: 0, withdrawals: 0, fees: 15.38 },
  { date: '2025-08-11', realizedPnl: 1123.67, unrealizedPnl: -23.45, deposits: 0, withdrawals: 0, fees: 15.56 },
  { date: '2025-08-12', realizedPnl: 2234.78, unrealizedPnl: 67.89, deposits: 0, withdrawals: 0, fees: 16.12 },
  { date: '2025-08-13', realizedPnl: 3089.45, unrealizedPnl: 112.34, deposits: 0, withdrawals: 1200, fees: 16.54 }
];

export const subaccountsData = [
  {
    id: 1,
    accountName: 'MainDayUSDT',
    accountType: 'Day Trading',
    sizeCad: 75600,
    leverage: '20x',
    exchange: 'Bitget',
    dailyPnl: 166.08,
    winRate: 0.644,
    maxDrawdown: 0.166,
    sharpeRatio: 2.52
  },
  {
    id: 2,
    accountName: 'HFTRisk',
    accountType: 'High-Frequency',
    sizeCad: 63400,
    leverage: '80x',
    exchange: 'Bitget',
    dailyPnl: 173.62,
    winRate: 0.629,
    maxDrawdown: 0.063,
    sharpeRatio: 1.47
  },
  {
    id: 3,
    accountName: 'BTCPerpSwing',
    accountType: 'Swing Trading',
    sizeCad: 51200,
    leverage: '5x',
    exchange: 'Phemex',
    dailyPnl: 111.17,
    winRate: 0.459,
    maxDrawdown: 0.099,
    sharpeRatio: 1.74
  },
  {
    id: 4,
    accountName: 'DeFiYield',
    accountType: 'Day Trading',
    sizeCad: 31000,
    leverage: '12x',
    exchange: 'Bitget',
    dailyPnl: 47.72,
    winRate: 0.504,
    maxDrawdown: 0.092,
    sharpeRatio: 1.96
  },
  {
    id: 5,
    accountName: 'ETHQuant',
    accountType: 'Day Trading',
    sizeCad: 29400,
    leverage: '15x',
    exchange: 'Phemex',
    dailyPnl: 89.88,
    winRate: 0.478,
    maxDrawdown: 0.170,
    sharpeRatio: 1.30
  },
  {
    id: 6,
    accountName: 'KrakenSwing',
    accountType: 'Swing Trading',
    sizeCad: 64300,
    leverage: '3x',
    exchange: 'Kraken',
    dailyPnl: -12.45,
    winRate: 0.412,
    maxDrawdown: 0.186,
    sharpeRatio: 1.2
  },
  {
    id: 7,
    accountName: 'SpotMain',
    accountType: 'Spot',
    sizeCad: 3900,
    leverage: 'N/A',
    exchange: 'Bitget',
    dailyPnl: 6.23,
    winRate: 0,
    maxDrawdown: 0,
    sharpeRatio: 0
  },
  {
    id: 8,
    accountName: 'SpotMinor',
    accountType: 'Spot',
    sizeCad: 1600,
    leverage: 'N/A',
    exchange: 'Kraken',
    dailyPnl: 1.45,
    winRate: 0,
    maxDrawdown: 0,
    sharpeRatio: 0
  },
  {
    id: 9,
    accountName: 'PhemexHedge',
    accountType: 'Futures',
    sizeCad: 55100,
    leverage: '50x',
    exchange: 'Phemex',
    dailyPnl: 234.56,
    winRate: 0.510,
    maxDrawdown: 0.113,
    sharpeRatio: 1.9
  },
  {
    id: 10,
    accountName: 'ArbitrageX',
    accountType: 'High-Frequency',
    sizeCad: 27500,
    leverage: '100x',
    exchange: 'Bitget',
    dailyPnl: 109.34,
    winRate: 0.630,
    maxDrawdown: 0.168,
    sharpeRatio: 2.5
  },
  {
    id: 11,
    accountName: 'KrakenFutAlt',
    accountType: 'Futures',
    sizeCad: 21500,
    leverage: '10x',
    exchange: 'Kraken',
    dailyPnl: 53.78,
    winRate: 0.450,
    maxDrawdown: 0.155,
    sharpeRatio: 1.5
  },
  {
    id: 12,
    accountName: 'LTCQuant',
    accountType: 'Day Trading',
    sizeCad: 27500,
    leverage: '25x',
    exchange: 'Phemex',
    dailyPnl: 1.23,
    winRate: 0.490,
    maxDrawdown: 0.139,
    sharpeRatio: 2.0
  }
];

export const transactionsData = [
  {
    id: 1,
    timestamp: '2025-08-09 18:41',
    account: 'ETHQuant',
    exchange: 'Phemex',
    type: 'Trade',
    asset: 'ETHUSDT',
    side: 'Long',
    quantity: 3.88,
    price: 2600.35,
    leverage: '15x',
    feeCad: 5.04,
    realizedPnlCad: 337.23,
    notes: 'Take Profit'
  },
  {
    id: 2,
    timestamp: '2025-08-09 15:44',
    account: 'BTCPerpSwing',
    exchange: 'Phemex',
    type: 'Trade',
    asset: 'BTCUSDT',
    side: 'Short',
    quantity: 0.286,
    price: 43079.61,
    leverage: '5x',
    feeCad: 6.16,
    realizedPnlCad: -78.20,
    notes: 'Stop Loss'
  },
  {
    id: 3,
    timestamp: '2025-08-09 20:01',
    account: 'DeFiYield',
    exchange: 'Bitget',
    type: 'Trade',
    asset: 'AVAXUSDT',
    side: 'Short',
    quantity: 602.9,
    price: 2.1759,
    leverage: '12x',
    feeCad: 0.66,
    realizedPnlCad: 42.39,
    notes: 'Market TP/SL'
  },
  {
    id: 4,
    timestamp: '2025-08-10 18:54',
    account: 'KrakenFutAlt',
    exchange: 'Kraken',
    type: 'Trade',
    asset: 'AVAXUSDT',
    side: 'Short',
    quantity: 462.0,
    price: 0.8898,
    leverage: '10x',
    feeCad: 0.21,
    realizedPnlCad: 96.26,
    notes: 'Take Profit'
  },
  {
    id: 5,
    timestamp: '2025-08-10 17:51',
    account: 'KrakenFutAlt',
    exchange: 'Kraken',
    type: 'Trade',
    asset: 'ADAUSDT',
    side: 'Long',
    quantity: 279.4,
    price: 2.0488,
    leverage: '10x',
    feeCad: 0.29,
    realizedPnlCad: -20.97,
    notes: 'Limit FOK'
  }
];

// Calculate summary metrics
export const portfolioSummary = {
  totalValue: subaccountsData.reduce((sum, account) => sum + account.sizeCad, 0),
  todaysPnl: subaccountsData.reduce((sum, account) => sum + account.dailyPnl, 0),
  mtdRealizedPnl: dailyPnlData.reduce((sum, day) => sum + day.realizedPnl, 0),
  mtdUnrealizedPnl: dailyPnlData.reduce((sum, day) => sum + day.unrealizedPnl, 0),
  avgSharpe: subaccountsData.filter(acc => acc.sharpeRatio > 0).reduce((sum, acc) => sum + acc.sharpeRatio, 0) / subaccountsData.filter(acc => acc.sharpeRatio > 0).length,
  maxDrawdown: Math.max(...subaccountsData.map(acc => acc.maxDrawdown))
};

export default {
  dailyPnlData,
  subaccountsData,
  transactionsData,
  portfolioSummary
};