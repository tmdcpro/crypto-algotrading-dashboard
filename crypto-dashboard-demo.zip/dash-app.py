import dash
from dash import html, dcc, Input, Output, State, callback, dash_table
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date
import numpy as np

# Load data
try:
    df_daily_pnl = pd.read_csv('../data/daily_pnl.csv')
    df_subaccounts = pd.read_csv('../data/subaccounts.csv')
    df_transactions = pd.read_csv('../data/transactions.csv')
except FileNotFoundError:
    print("Data files not found. Make sure to run from python_dash_version/ directory and have data/ folder with CSV files.")
    # Create sample data as fallback
    df_daily_pnl = pd.DataFrame({
        'date': ['2025-08-01', '2025-08-02', '2025-08-03'],
        'realized_pnl': [1555.89, 2348.18, 2693.60],
        'unrealized_pnl': [179.54, 3.17, -43.89],
        'deposits': [2000, 0, 0],
        'withdrawals': [0, 0, 0],
        'fees': [15.78, 16.17, 16.35]
    })
    df_subaccounts = pd.DataFrame({
        'account_name': ['MainDayUSDT', 'HFTRisk'],
        'account_type': ['Day Trading', 'High-Frequency'],
        'size_cad': [75600, 63400],
        'leverage': ['20x', '80x'],
        'exchange': ['Bitget', 'Bitget'],
        'daily_pnl': [166.08, 173.62],
        'win_rate': [0.644, 0.629],
        'max_drawdown': [0.166, 0.063],
        'sharpe_ratio': [2.52, 1.47]
    })
    df_transactions = pd.DataFrame({
        'timestamp': ['2025-08-09 18:41', '2025-08-09 15:44'],
        'account': ['ETHQuant', 'BTCPerpSwing'],
        'exchange': ['Phemex', 'Phemex'],
        'type': ['Trade', 'Trade'],
        'asset': ['ETHUSDT', 'BTCUSDT'],
        'side': ['Long', 'Short'],
        'quantity': [3.88, 0.286],
        'price': [2600.35, 43079.61],
        'fee_cad': [5.04, 6.16],
        'realized_pnl_cad': [337.23, -78.20]
    })

# Initialize the Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "Crypto Algotrading Dashboard"

# Calculate summary statistics
total_portfolio_value = df_subaccounts['size_cad'].sum()
total_daily_pnl = df_subaccounts['daily_pnl'].sum()
mtd_realized_pnl = df_daily_pnl['realized_pnl'].sum()
mtd_unrealized_pnl = df_daily_pnl['unrealized_pnl'].sum()
avg_sharpe = df_subaccounts[df_subaccounts['sharpe_ratio'] > 0]['sharpe_ratio'].mean()
max_drawdown = df_subaccounts['max_drawdown'].max()

# Layout
app.layout = dbc.Container([
    # Header
    dbc.Row([
        dbc.Col([
            html.H1("🚀 Crypto Algotrading Portfolio Dashboard", className="text-center mb-4"),
            html.P("Multi-exchange algorithmic trading portfolio with real-time P&L tracking", 
                   className="text-center text-muted")
        ])
    ]),
    
    # KPI Cards
    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H4(f"${total_portfolio_value:,.0f}", className="text-success"),
                    html.P("Total Portfolio Value (CAD)", className="mb-0")
                ])
            ])
        ], width=3),
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H4(f"${total_daily_pnl:,.0f}", className="text-info"),
                    html.P("Today's P&L", className="mb-0")
                ])
            ])
        ], width=3),
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H4(f"${mtd_realized_pnl:,.0f}", className="text-primary"),
                    html.P("Month-to-Date P&L", className="mb-0")
                ])
            ])
        ], width=3),
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H4(f"{avg_sharpe:.2f}", className="text-warning"),
                    html.P("Avg Sharpe Ratio", className="mb-0")
                ])
            ])
        ], width=3),
    ], className="mb-4"),
    
    # Filters Row
    dbc.Row([
        dbc.Col([
            dcc.DatePickerRange(
                id='date-range-picker',
                start_date=df_daily_pnl['date'].min(),
                end_date=df_daily_pnl['date'].max(),
                display_format='YYYY-MM-DD',
                style={'width': '100%'}
            )
        ], width=4),
        dbc.Col([
            dcc.Dropdown(
                id='exchange-filter',
                options=[{'label': 'All Exchanges', 'value': 'all'}] + 
                        [{'label': ex, 'value': ex} for ex in df_subaccounts['exchange'].unique()],
                value='all',
                placeholder="Filter by Exchange"
            )
        ], width=4),
        dbc.Col([
            dcc.Dropdown(
                id='account-type-filter',
                options=[{'label': 'All Types', 'value': 'all'}] + 
                        [{'label': typ, 'value': typ} for typ in df_subaccounts['account_type'].unique()],
                value='all',
                placeholder="Filter by Account Type"
            )
        ], width=4),
    ], className="mb-4"),
    
    # Charts Row
    dbc.Row([
        dbc.Col([
            dcc.Graph(id="daily-pnl-chart")
        ], width=8),
        dbc.Col([
            dcc.Graph(id="allocation-pie-chart")
        ], width=4),
    ], className="mb-4"),
    
    # Subaccounts Table
    dbc.Row([
        dbc.Col([
            html.H3("Sub-Accounts Performance"),
            dash_table.DataTable(
                id='subaccounts-table',
                columns=[
                    {'name': 'Account', 'id': 'account_name'},
                    {'name': 'Type', 'id': 'account_type'},
                    {'name': 'Size (CAD)', 'id': 'size_cad', 'type': 'numeric', 'format': {'specifier': ',.0f'}},
                    {'name': 'Leverage', 'id': 'leverage'},
                    {'name': 'Exchange', 'id': 'exchange'},
                    {'name': 'Daily P&L', 'id': 'daily_pnl', 'type': 'numeric', 'format': {'specifier': ',.2f'}},
                    {'name': 'Win Rate', 'id': 'win_rate', 'type': 'numeric', 'format': {'specifier': '.1%'}},
                    {'name': 'Max DD', 'id': 'max_drawdown', 'type': 'numeric', 'format': {'specifier': '.1%'}},
                    {'name': 'Sharpe', 'id': 'sharpe_ratio', 'type': 'numeric', 'format': {'specifier': '.2f'}},
                ],
                data=df_subaccounts.to_dict('records'),
                style_cell={'textAlign': 'left'},
                style_data_conditional=[
                    {
                        'if': {'column_id': 'daily_pnl', 'filter_query': '{daily_pnl} > 0'},
                        'backgroundColor': '#d4edda',
                        'color': 'black',
                    },
                    {
                        'if': {'column_id': 'daily_pnl', 'filter_query': '{daily_pnl} < 0'},
                        'backgroundColor': '#f8d7da',
                        'color': 'black',
                    }
                ],
                sort_action="native",
                filter_action="native",
                page_size=12,
                editable=True
            )
        ])
    ], className="mb-4"),
    
    # Recent Transactions
    dbc.Row([
        dbc.Col([
            html.H3("Recent Transactions"),
            dash_table.DataTable(
                id='transactions-table',
                columns=[
                    {'name': 'Time', 'id': 'timestamp'},
                    {'name': 'Account', 'id': 'account'},
                    {'name': 'Exchange', 'id': 'exchange'},
                    {'name': 'Asset', 'id': 'asset'},
                    {'name': 'Side', 'id': 'side'},
                    {'name': 'Quantity', 'id': 'quantity', 'type': 'numeric', 'format': {'specifier': '.3f'}},
                    {'name': 'Price', 'id': 'price', 'type': 'numeric', 'format': {'specifier': ',.2f'}},
                    {'name': 'Fee (CAD)', 'id': 'fee_cad', 'type': 'numeric', 'format': {'specifier': ',.2f'}},
                    {'name': 'P&L (CAD)', 'id': 'realized_pnl_cad', 'type': 'numeric', 'format': {'specifier': ',.2f'}},
                ],
                data=df_transactions.to_dict('records'),
                style_cell={'textAlign': 'left'},
                style_data_conditional=[
                    {
                        'if': {'column_id': 'realized_pnl_cad', 'filter_query': '{realized_pnl_cad} > 0'},
                        'backgroundColor': '#d4edda',
                        'color': 'black',
                    },
                    {
                        'if': {'column_id': 'realized_pnl_cad', 'filter_query': '{realized_pnl_cad} < 0'},
                        'backgroundColor': '#f8d7da',
                        'color': 'black',
                    }
                ],
                sort_action="native",
                filter_action="native",
                page_size=10
            )
        ])
    ])
    
], fluid=True)

# Callbacks
@app.callback(
    Output('daily-pnl-chart', 'figure'),
    [Input('date-range-picker', 'start_date'),
     Input('date-range-picker', 'end_date')]
)
def update_pnl_chart(start_date, end_date):
    filtered_df = df_daily_pnl[
        (df_daily_pnl['date'] >= start_date) & 
        (df_daily_pnl['date'] <= end_date)
    ]
    
    fig = go.Figure()
    
    # Add realized PNL bars
    fig.add_trace(go.Bar(
        x=filtered_df['date'],
        y=filtered_df['realized_pnl'],
        name='Realized P&L',
        marker_color='#2E8B57'
    ))
    
    # Add unrealized PNL line
    fig.add_trace(go.Scatter(
        x=filtered_df['date'],
        y=filtered_df['unrealized_pnl'],
        mode='lines+markers',
        name='Unrealized P&L',
        line=dict(color='#FF6347', width=2),
        yaxis='y2'
    ))
    
    fig.update_layout(
        title='Daily P&L Performance',
        xaxis_title='Date',
        yaxis=dict(title='Realized P&L (CAD)', side='left'),
        yaxis2=dict(title='Unrealized P&L (CAD)', side='right', overlaying='y'),
        hovermode='x unified',
        template='plotly_white'
    )
    
    return fig

@app.callback(
    Output('allocation-pie-chart', 'figure'),
    [Input('exchange-filter', 'value'),
     Input('account-type-filter', 'value')]
)
def update_allocation_chart(exchange_filter, type_filter):
    filtered_df = df_subaccounts.copy()
    
    if exchange_filter != 'all':
        filtered_df = filtered_df[filtered_df['exchange'] == exchange_filter]
    
    if type_filter != 'all':
        filtered_df = filtered_df[filtered_df['account_type'] == type_filter]
    
    fig = px.pie(
        filtered_df, 
        values='size_cad', 
        names='account_name',
        title='Portfolio Allocation by Sub-Account'
    )
    
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(template='plotly_white')
    
    return fig

@app.callback(
    Output('subaccounts-table', 'data'),
    [Input('exchange-filter', 'value'),
     Input('account-type-filter', 'value')]
)
def update_subaccounts_table(exchange_filter, type_filter):
    filtered_df = df_subaccounts.copy()
    
    if exchange_filter != 'all':
        filtered_df = filtered_df[filtered_df['exchange'] == exchange_filter]
    
    if type_filter != 'all':
        filtered_df = filtered_df[filtered_df['account_type'] == type_filter]
    
    return filtered_df.to_dict('records')

if __name__ == '__main__':
    app.run_server(debug=True, host='0.0.0.0', port=8050)